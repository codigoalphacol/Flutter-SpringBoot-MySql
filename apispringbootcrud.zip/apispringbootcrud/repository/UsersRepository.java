package com.codigo.alpha.apispringbootcrud.repository;

import com.codigo.alpha.apispringbootcrud.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepository extends JpaRepository<User, Integer> {
    User findByName(String name);
}
