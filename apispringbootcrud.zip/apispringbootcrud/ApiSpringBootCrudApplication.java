package com.codigo.alpha.apispringbootcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSpringBootCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiSpringBootCrudApplication.class, args);
    }

}
